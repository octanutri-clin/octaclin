# Parecer integrado — Fase 314 do OctaClin

**Data:** 2026-10-10  
**Natureza:** revisão documental clínica, funcional, arquitetural e de segurança; não é ratificação clínica independente nem auditoria do código em execução.  
**Resultado:** **PLANEJAMENTO APROVADO COM CONDICIONANTES. CLASSIFICADOR AINDA BLOQUEADO (`G01/G02`).**  
**Alterações:** versões `rev1` da ficha clínica, handoff e tarefas T01–T18, preservando os arquivos originais do usuário.

## 1. Documentos revisados e limites da análise

- `FICHA_VALIDACAO_CLINICA_FASE_314.md`: regras propostas, séries OMS/INTERGROWTH, cortes SISVAN, idade, técnica, fórmulas adultas; sem ratificação da equipe.
- `plan-fase-314.md`: estado operacional e handoff, gates, branch, escopo, dependências 313/1068.
- `todo-fase-314.md`: implementação planejada T01–T18; nenhuma tarefa de código declarada executada.
- **Não fornecidos nesta rodada:** `docs/history/phases/PLANO_FASE_314.md` integral, `docs/product/FONTES_ANTROPOMETRIA_FASE_314.md`, fontes computacionais e hashes, e código/testes da branch local. Logo **não foi possível confirmar quantitativamente os 16 datasets alegados, licenças, schema ou contratos de integração**.
- **GitHub conferido:** PR #391 da Fase 313 mergeado; commit base `f8c5ab66f2708d4a73fc31d460f929a665bd6f08` disponível. Branch `docs/fase-314-planejamento` não localizada no remoto nessa consulta. **Não houve acesso direto a staging/produção** nem confirmação de aplicação da migration `1068`.

## 2. Matriz de avaliação

| Área | Parecer | Condição de liberação |
| --- | --- | --- |
| Escolha de OMS 2006/2007 e SISVAN | Fundamento documental adequado; não é ratificação clínica | Confirmar indicadores/populações/rótulos, métodos e idades `CL-01`, `CL-04` |
| OMS 2007: idade e interpolação | **Correção relevante incorporada** | Reproduzir idade exata em meses e interpolação do WHO AnthroPlus; não equivaler a lookup por mês inteiro |
| Comprimento/estatura 0,7 cm | Adequado com ressalva | Menores de 9 meses com medida em pé: sinalizar, não normalizar sem revisão clínica `CL-02` |
| LMS, caudas, percentis e flags | Matematicamente plausível, mas insuficiente para aprovação | Fixtures independentes OMS e casos de extremos + flags por indicador `CL-03`, `CL-09` |
| Classificações SISVAN | Estrutura de pontos de corte condizente com quadros oficiais | Rótulos completos e igualdade em z = −3/−2/+1/+2/+3 `CL-04` |
| INTERGROWTH pós-natal | Referência clínica apropriada para população selecionada, condicionada | Elegibilidade e algoritmo por dia oficial/comprovado `CL-05`, `CL-06` |
| Transição 64s0d e idade corrigida | Proposta defensável, **não ratificada** | Definir PMA, data exata, começo/fim da correção, base cronológica/corrigida `CL-07` |
| Fórmulas adultas 18–19 e gestação | Proteção <18 proposta, 18–19 aberta | Matriz clínica por fórmula e precedência do estado gestacional `CL-08` |
| Snapshots, RLS, replay e segurança | Arquitetura planejada coerente | Evidências em PostgreSQL real e revisão R4, sem inferir do PR anterior |
| Gráfico, BFF e console | Escopo coerente, sem portal pediátrico | Testar cobertura/cursor, acessibilidade, erros de permissão, ausência de PHI |
| Rollback e migrations | Estratégia conservadora recomendável | Verificação real da 1068 e rollback que preserve dados antes de deploy |

## 3. Achados prioritários

### P0 — impedem liberar classificador ou deploy

1. **G01, método computacional neonatal ausente:** a publicação de tabelas com escores por semana exata não comprova método para **cada dia**. Exigir fonte/método independente e licença, ou preservar medidas sem classificação.
2. **G02, população e correção prematura ainda não ratificadas:** confirmar elegibilidade, idade corrigida, limite de duração e transição 64s0d/64s1d.
3. **Método OMS 2007 precisa ser detalhado:** WHO AnthroPlus usa idade exata e interpolação própria. Uma consulta direta a mês completo pode gerar resultado divergente sem exceção visível.
4. **Revisão clínica humana pendente:** os itens propostos na ficha não equivalem a aceite do responsável pela prática clínica.
5. **Disponibilidade operacional antes de deploy:** migration 1068 e condições dos ambientes não foram comprovadas por consulta direta nesta revisão.

### P1 — corrigir contrato e testar antes de merge

6. **Técnica em pé <9 meses:** guideline WHO Anthro Survey Analyser desconsidera a medição para cálculo; procedimento clínico no OctaClin requer ratificação, sem apagar o original.
7. **Flags e edema:** separar medidas, escores e indicadores conforme plausibilidade; não confundir exclusão populacional para prevalência com diagnóstico individual.
8. **Rótulos:** usar nomes completos por indicador e faixa; peso elevado/idade não define obesidade.
9. **Versionamento completo:** guardar contexto e referência efetiva, método/versão/hash e idade de cálculo, sem recálculo de legado.
10. **Autorização dos dados de menores:** isolamento, acesso profissional, minimização, cifragem e telemetria sem PHI; portal pediátrico segue explicitamente fora do escopo.
11. **Regressões 313/legados:** bloqueios gestacionais têm precedência; sistemas 313, adultos, idosos, documentos, portal e séries históricas não podem ser afetados implicitamente.

### P2 — disciplina de execução

12. Provar integridade, direitos e cardinalidade da origem de dados, não inferir "16 fontes" do texto do handoff.
13. Registrar comparação contra `anthro` oficial OMS 2006 e AnthroPlus/`anthroplus` OMS 2007 com tolerâncias motivadas.
14. Provar idempotência, concorrência, RLS FORCE e runtime não-owner com PostgreSQL real.
15. Marcar `PASS/FAIL/BLOCKED/SKIPPED` com evidências, em vez de converter promessa de teste em teste executado.

## 4. Respostas que precisam de decisão documentada

A ficha revisada organiza `CL-01…CL-10`, envolvendo (i) idade e tabelas, (ii) técnica, (iii) matemática/percentis/flags, (iv) rótulos, (v) elegibilidade prematura, (vi) método computacional neonatal, (vii) transição e correção, (viii) fórmulas adultas de 18–19, (ix) plausibilidade/edema, (x) governança de informações infantis. **Todas permanecem pendentes de ratificação formal.** Não selecionar automaticamente um prazo de 2 ou 3 anos de idade corrigida apenas porque uma entidade o publica; apresentar alternativas e obter decisão.

## 5. Protocolo mínimo de testes a exigir do Codex

1. **Idade:** dia de nascimento/dia seguinte, 730/731, 1856/1857 dias, 60/61, 120/121, 228/229 meses, 29 de fevereiro, DST e nascimento após avaliação.
2. **Método OMS:** cada sexo, cada família de indicador, mediana, L=0, caudas ±3, valor bruto nos limiares, percentil `NA` quando indevido e resultados independentes do software da OMS.
3. **Flags:** HFA <−6/>+6; WFA <−6/>+5; WFL/WFH <−5/>+5; BFA <−5/>+5, seus limites exatos, missing e edema caso previsto.
4. **Técnica:** deitado/em pé, antes de nove meses, 730/731, +0,7/−0,7, original preservado e ajuste único, faixas cm fora da grade.
5. **Prematuros:** PMA 26s6d, 27s0d, 64s0d, 64s1d, 64s6d; IG 32s0d + 28 dias; semanas + dias, bases incompletas, múltiplos/morbidade/RCIU e término de idade corrigida.
6. **Segurança:** tenant cruzado, carteira revogada, replay, concorrência, retificação, transferência de paciente, soft-delete, >100 medidas, duplicatas por data e cursor estável.
7. **Experiência:** avaliação → resultado parcial → histórico → gráfico → próxima página; acessibilidade; sem classificação no browser, novo portal, log clínico inadvertido ou exposição via documentos.

A tolerância numérica não deve ser escolhida para ocultar divergência entre um algoritmo inventado e uma fonte oficial.

## 6. Sequência e autorização

- **Agora:** T01 (resolver manifesto + computação + idade e fontes) e T02 (aprovação clínica documentada), limitadas à análise, à ficha e ao planejamento.
- **Depois, apenas com G01/G02 e autorização de implementação:** T03–T06 (núcleo OMS e persistência), checkpoint de regressão; T07–T11 (indicadores restantes, prematuros e bloqueios adultos), checkpoint; T12–T15 (projeção/BFF/formulário/gráfico), checkpoint; T16–T18 (PostgreSQL real, segurança, suites, revisão independente e PR única).
- **Sem autorização nesta análise:** executar migrations em ambiente externo, afirmar produção saudável, publicar dados de menores, criar portal, mesclar a PR ou implantar a Fase 314.
- **Se G01 não for resolvido:** renegociar expressamente o escopo com o proprietário; nunca entregar percentil/escore diário neonatal estimado de tabelas semanais sob o mesmo rótulo de validade.

## 7. Critério para aprovação definitiva

`PASS` apenas com: `CL-01…CL-10` respondidas e ratificadas; fontes oficiais verificadas e hash/termos arquivados; fixture externa para cada método; provas R4 em banco real; CI final; revisão de segurança; confirmação independente da migration 1068 e condição do ambiente. Caso contrário, relatório deve identificar `BLOCKED` ou `SKIPPED` sem inferência.

## 8. Referências consultadas

- WHO 2006 — https://www.who.int/publications/i/item/924154693X
- WHO 2007 — https://www.who.int/tools/growth-reference-data-for-5to19-years
- WHO AnthroPlus — https://www.who.int/docs/default-source/child-growth/growth-reference-5-19-years/who-anthroplus-manual.pdf
- WHO Anthro Survey Analyser — https://www.who.int/docs/default-source/child-growth/child-growth-standards/software/anthro-survey-analyser-quickguide.pdf
- WHO Software e referência 2006 — https://www.who.int/toolkits/child-growth-standards/software
- Ministério da Saúde/SISVAN — https://www.gov.br/saude/pt-br/composicao/saps/vigilancia-alimentar-e-nutricional/arquivos/protocolos-do-sistema-de-vigilancia-alimentar-e-nutricional-sisvan/view
- INTERGROWTH z-scores e centis — https://intergrowth21.tghn.org/articles/intergrowth-21st-postnatal-growth-standards-and-z-scores-preterm-infants/
- Villar et al. 2015 — https://doi.org/10.1016/S2214-109X(15)00163-1
- AAP, idade corrigida — https://www.aap.org/en/patient-care/newborn-infant-and-early-childhood-nutrition/newborn-and-infant-nutrition-assessment-tools/term-infant-growth-tools/

## 9. Mensagem condensada para enviar ao Codex

> Use os três arquivos `*_REVISADO.md` e este parecer como proposta documental revisada, compare com os originais e com `PLANO_FASE_314.md`/`FONTES_ANTROPOMETRIA_FASE_314.md` locais. **Não altere valores clínicos por inferência e não marque G01/G02 como concluídos.** Valide OMS 2006/2007, interpolação OMS 2007, técnica <9 meses, flags, rótulos, elegibilidade e método computacional INTERGROWTH por dia. Registre divergências, evidências e perguntas CL-01…CL-10. Peça aceite humano. Sem G01/G02 e autorização de código, não avance além da preparação documental; não aplique migration, não faça merge/deploy e não exponha PHI em logs, portal ou testes. Após aceite, implemente T03–T18 em commits pequenos com testes e revisão R4, preservando 313/312 e o histórico.

---

**Conclusão:** o planejamento pode ser adotado **como documento de trabalho**, mas a aprovação clínica final e a execução do classificador estão **bloqueadas por G01/G02**. Este parecer não atribui assinatura/competência clínica à IA e não substitui revisão do material computacional ou verificação do ambiente.
