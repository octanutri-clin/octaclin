# Handoff de planejamento — Fase 314

> Revisão independente documental `rev1`, 2026-10-10. **Planejamento aprovado com condicionantes; G01/G02 continuam abertos.** Não ratifica a ficha clínica nem autoriza código, migration, merge ou deploy.

## Objetivo e estado

Planejar antropometria pediátrica com quatro indicadores, gráfico no console
e prematuros INTERGROWTH → OMS com idade corrigida. **Somente planejamento**;
não existe implementação da 314, PR de entrega nem autorização de deploy.

Branch: `docs/fase-314-planejamento`; base `origin/main` `f8c5ab66` (PR #391).
Worktree: `/workspace/octaclin/.worktrees/docs-fase-314-planejamento`.
Plano: [PLANO_FASE_314.md](../docs/history/phases/PLANO_FASE_314.md).
Ficha: [FICHA_VALIDACAO_CLINICA_FASE_314.md](../docs/product/FICHA_VALIDACAO_CLINICA_FASE_314.md).
Fontes: [FONTES_ANTROPOMETRIA_FASE_314.md](../docs/product/FONTES_ANTROPOMETRIA_FASE_314.md).
Execução futura: [todo-fase-314.md](todo-fase-314.md).

O handoff 313 em `plan.md` contém gates operacionais/revisão ainda pendentes.
Este rascunho separado preserva todos eles; definir a promoção para `plan.md`
após fechar as perguntas, preservando o original no histórico.

## Verificação externa limitada desta revisão

- No GitHub foi confirmado o merge do **PR #391** e o commit `f8c5ab66f2708d4a73fc31d460f929a665bd6f08` como base referida no handoff. Isso **não comprova** aplicação da migration `1068`.
- A branch `docs/fase-314-planejamento` não apareceu no repositório remoto na consulta desta revisão; não foi possível inspecionar os documentos exclusivos da worktree local.
- Os arquivos técnicos completos `PLANO_FASE_314.md` e `FONTES_ANTROPOMETRIA_FASE_314.md` **não foram anexados** nesta rodada. Consequentemente, as tarefas, hashes, "16 fontes", rollback detalhado e contratos internos são **relatos não reexecutados**.
- A Ficha Clínica `rev1` identifica decisões `CL-01…CL-10`, ainda **não ratificadas**.

## Concluído (conforme relato do handoff original, não reexecutado externamente)

- [x] Conferir merge #391/CI pós-merge; não inferir aplicação da 1068.
- [x] Inventariar cálculo/DTO/snapshot/UI/consumidores/portal e gaps.
- [x] Obter/inspecionar fontes oficiais públicas e hashes; runtime offline.
- [x] Registrar decisões recebidas e propostas técnicas verificáveis.
- [x] Preparar arquitetura, tarefas pequenas, matriz de provas e rollback.
- [x] Links locais, `git diff --check` e `pnpm security:secrets` PASS.

## Pendente

- [x] Registrar etapa INTERGROWTH sem SISVAN, elegibilidade definida pela equipe
  e proposta para revisão de transição após 64s0d.
- [ ] Consolidar duração/base da idade corrigida e elegibilidade detalhada.
- [ ] Fechar métodos mensais/caudas/flags e referência computacional neonatal
  suficiente: não interpolar escores a partir de tabelas arredondadas.
- [ ] Ratificação clínica da ficha consolidada, incluindo política 18–19.
- [ ] Autorização de implementação e de seu escopo de testes.
- [ ] Conferência operacional externa da 1068 antes de liberar a aplicação;
  ausência de confirmação continua SKIPPED, sem executar neste planejamento.

## Próxima ação exata

Incorporar as respostas pendentes à ficha e ao plano; fechar G01 e enviar a
ficha consolidada para revisão clínica. Não começar o classificador enquanto
G01/G02 não estiverem ratificados. Se falta fonte/coeficiente, registrar esse
item explicitamente, sem fabricar algoritmo neonatal.

## Gates e ordem obrigatória de execução — revisão `rev1`

| Gate | Obrigação | Estado nesta revisão |
| --- | --- | --- |
| G00 | Git/branch/diff; manifesto real, hashes, termos; status real de `1068` | `PARCIAL` |
| G01 | Método OMS 2006/2007 exato + referência neonatal computável por dia, sem aproximação inventada | `BLOCKED` |
| G02 | Ratificação clínica formal `CL-01…CL-10` | `BLOCKED` |
| G03 | Autorização de código e escopo T03–T18 pelo proprietário | `PENDENTE` |
| G04 | Regressões, autorização/RLS PostgreSQL real, snapshots/consumidores e segurança | `NÃO EXECUTADO` |
| G05 | Revisão R4, CI no HEAD final, status operacional de migration e ambiente | `NÃO AUTORIZADO` |

**Sequência de trabalho segura:** primeiro revisar fontes/métodos/manifesto (T01), depois obter ratificação clínica (T02); somente **com G01/G02 e autorização expressa**, começar T03–T18. É possível preparar documentação e fixtures sintéticas sem desbloquear código; isso não libera algoritmos nem chamadas de serviço.

## Contratos que precisam constar no plano técnico integral

1. **Precedência clínica:** gestação explícita prevalece; prematuridade/IG incompleta impede fallback adulto ou infantil especulativo. Resultado por indicador pode ser `classificado`, `não aplicável`, `insuficiente` ou `inconsistente`, com motivo.
2. **Idade:** dias civis, meses efetivos OMS 2007/interpolação AnthroPlus, PMA, idade corrigida e adaptação SISVAN dos 19 anos documentados separadamente. Bordas 730/731, 60/61, 120/121, 228/229 e 64s0d/64s1d.
3. **Técnica:** valor original, modalidade observada, ajuste +0,7/−0,7 e contexto preservados. Medida em pé em menores de nove meses é inconsistência a reconferir, não correção automática sem decisão clínica.
4. **Cálculo:** tabelas oficiais versionadas, caudas/percentis e flags por indicador; comparar com OMS `anthro` e `AnthroPlus`/`anthroplus`. INTERGROWTH requer algoritmo próprio com fonte diária verificável.
5. **Dados de menores:** minimização, criptografia, segregação tenant/paciente, autenticação profissional, RLS com runtime não-owner, registros/logs sem PHI e nenhum novo portal pediátrico.
6. **Histórico:** imutabilidade de avaliações/snapshots, idempotência, versionamento de fonte, retificação via novo evento (não edição silenciosa) e gráfico sem unir bases incompatíveis.
7. **Falhas e rollback:** não usar down destrutivo, não eliminar snapshots; desativar nova leitura/classificação preservando dados. Status da migration `1068` e saúde externa são gates operacionais independentes.
8. **Validação:** testes unitários + fixtures independentes + PostgreSQL real + authz + UI + consumos históricos. Mediana LMS correta é necessária mas não suficiente para ratificar algoritmo.

## Modelos

GPT-6.1 Sol médio para algoritmo/persistência/integração; Luna alto pode assumir
as telas quando o contrato estiver fechado. A troca é manual: avisar e pausar.
O mesmo modelo atual dá conta do planejamento e do núcleo da implementação.

## Limites das evidências

Downloads/inspeção documental não são ratificação clínica. Testes da 314 não
executados, sem código implementado. Nenhum PHI/PII real enviado a fontes,
GitHub ou providers; somente dados públicos e fixtures futuras sintéticas.
Não fechar revisão independente/saúde de produção pelo CI da fase anterior.

## Mensagem pronta para o Codex — análise pré-implementação

> Leia `FICHA_VALIDACAO_CLINICA_FASE_314_REVISADA.md`, `plan-fase-314_REVISADO.md`, `todo-fase-314_REVISADO.md`, o plano integral e o manifesto das fontes. G01 e G02 estão `BLOCKED`; não invente validação clínica. Confronte quantidade/hashes/licenças de dados, método de idade e interpolação OMS 2007, exceção <9 meses, flags, 19 anos e escores INTERGROWTH por dia; crie matriz divergência→arquivo→correção→evidência. Aguarde autorização expressa antes de T03 ou alterações de runtime. Mantenha uma PR de entrega e um escritor, não altere portal, não use PHI nos ensaios, não aplique migration nem faça merge/deploy. Preserve pendências da Fase 313 e evidências PASS/FAIL/BLOCKED/SKIPPED; avise caso a referência computacional neonatal não possa ser comprovada.
