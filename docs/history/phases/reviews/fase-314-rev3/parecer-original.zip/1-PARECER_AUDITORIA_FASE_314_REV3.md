# Parecer de auditoria independente documental — Fase 314 (rev3)

**Data:** 2026-10-10  
**Escopo:** avaliação dos seis documentos atualizados pelo Codex, comparação com decisões anteriores e pesquisa complementar dirigida sobre a lacuna neonatal G01.  
**Status:** **PLANEJAMENTO DOCUMENTAL APROVADO COM RESSALVAS; CLASSIFICADOR CLÍNICO NÃO RATIFICADO; IMPLEMENTAÇÃO NÃO AUTORIZADA.**

> Isto é revisão técnica e documental, não aprovação clínica formal, parecer jurídico, auditoria de ambiente nem teste funcional do código. As observações externas são apresentadas como fontes de pesquisa, não como evidência de validação de implementação.

## 1. Material examinado

1. `todo-fase-314 2.md` — sequência T01–T18 rev2;
2. `REVISAO_PLANEJAMENTO_FASE_314.md` — relato do Codex, matriz D01–D17 e limites;
3. `FICHA_VALIDACAO_CLINICA_FASE_314 2.md` — matriz CL-01–CL-10;
4. `FONTES_ANTROPOMETRIA_FASE_314.md` — artefatos, grades, hashes e direitos;
5. `plan-fase-314 2.md` — handoff e gates;
6. `PLANO_FASE_314.md` — arquitetura, riscos, modelo de persistência e rollout.

Os seis arquivos estavam legíveis e foram examinados. Há cobertura textual de T01–T18 na sequência de tarefas, de CL-01–CL-10 na ficha e de G00–G05 nos relatórios/planos. **Não foram executadas suítes do OctaClin, migrações nem acesso aos bancos** nesta revisão. Claims de PASS operacional referem-se ao relato do Codex, não a execução repetida por este parecer.

## 2. Conclusão por domínio

| Domínio | Parecer | Condição necessária |
| --- | --- | --- |
| Coerência do planejamento | **APROVADO COM RESSALVAS** | Incorporar achados rev3 e manter histórico de decisões |
| OMS 2006/2007 — método | **PARCIALMENTE FUNDAMENTADO** | Fechar CL-01/02/03/04/09, edição, âncoras, flags, igualdade e testes-oráculo |
| SISVAN — rótulos/cortes | **PENDENTE DE RATIFICAÇÃO CLÍNICA** | Confirmar intervalos sem sobreposição e terminologia por indicador/faixa |
| Prematuros/INTERGROWTH | **BLOCKED** | Resolver equações/modelo diário, população, primeira medida, transição/idade corrigida e direitos |
| Fórmulas adultas 18–19 | **BLOCKED CL-08** | Aprovar elegibilidade fórmula a fórmula, sem usar faixa do código como comprovação clínica |
| Segurança R4 | **PLANEJADA, NÃO TESTADA** | PG com role não-owner, RLS, replay, allowlists, migração, CI e revisão final |
| Deploy | **NÃO AUTORIZADO** | G05 e verificação operacional da migration 1068, ambientes, permissões e saúde |

## 3. O que a rev2 resolveu bem

- Matriz clínica rastreável CL-01–CL-10 com distinção entre fato documental, decisão de produto, recomendação técnica e decisão clínica.
- Separação entre idade civil, idade estatística/OMS e adaptação SISVAN; interpolação L/M/S na OMS 2007, com âncoras necessárias.
- Regra conservadora para comprimento/estatura e destaque de posição em pé abaixo de nove meses como decisão clínica específica, não equivalência exata à biblioteca estatística OMS.
- Snapshots cifrados; não inferir sexo, prematuridade ou técnica; preservação de histórico e bloqueios gestacionais.
- Testes de PostgreSQL real antecipados: T16-A após T06 e T16-B após T12, antes de BFF/UI; T11 antes da primeira persistência pediátrica.
- Paginação por registros examinados, não por resultados presentes dentro de um blob cifrado; cursor SQL total e cobertura parcial explícita.
- Não confundir trigger de UPDATE da 1068 com proteção contra DELETE físico; nem merge/CI da 313 com migration aplicada ou produção saudável.
- Registro claro de direitos/licenças e proibição de copiar código GPL em runtime sem avaliação.

## 4. Achados novos para integrar (não cobertos integralmente na rev2)

### N01 — P0 / G01 — Equações contínuas candidatas para INTERGROWTH

A pesquisa complementar identificou código científico com **equações explícitas para μ/σ dependentes da idade pós-menstrual**, sem precisar derivar escores diários de PDF semanal arredondado:

- **rOpenSci `gigs`** (GPL >=3): `https://github.com/ropensci/gigs/blob/main/R/ig_png.R`. O código explicita equações para `wfa` e `lfa`, além de `hcfa` e `wfl`; para peso e comprimento usa transformação logarítmica.
- **ki-tools `growthstandards`** (MIT declarada no pacote): `https://github.com/ki-tools/growthstandards/blob/master/R/standard_igprepost.R`. Usa equações de coeficientes coincidentes para peso/comprimento; há diferenças de política de extremos/intervalos a auditar.
- Documentação: `https://docs.ropensci.org/gigs/` e `https://ki-tools.github.io/growthstandards/`.

**Impacto:** a assertiva “não há modelo computacional identificado” pode ser substituída por “há implementações candidatas pesquisáveis, ainda não validadas/licitadas para incorporação”. A existência dessas implementações **não** transforma G01 em PASS.

**Ação T01-C/CL-06:** fixar release/commit de ambos os projetos; identificar fonte primária dos coeficientes (publicação/suplemento ou confirmação do consórcio), unidades e transformações; estudar diferenças de intervalo e precisão; comparar resultados sintéticos a um oráculo INTERGROWTH oficial independente; documentar licenças/direitos dos dados e eventual autorização para uso comercial. Não copiar código GPL nem inserir dependências runtime. O segundo repositório pode funcionar como contraponto, mas equações idênticas não são prova estatística independente.

### N02 — P0 / CL-05 — Primeira medida ao nascer versus avaliação pós-natal

A documentação do `gigs` diferencia a avaliação inicial ao nascimento (padrões *Newborn Size*) do acompanhamento pós-natal de prematuros (padrões *Postnatal Growth*). Essa distinção requer uma decisão explícita no OctaClin; PMA dentro de 27–64 semanas não autoriza, sozinha, aplicar uma referência pós-natal a uma medida de nascimento.

**Ação T02/T03/T09:** delimitar o tratamento de avaliação no dia 0, primeira medida em 0–2 dias e avaliação subsequente; diferenciar `nao_aplicavel`, `insuficiente` e `inconsistente`. **Não** acrescentar automaticamente a referência de tamanho ao nascer, pois isso constitui ampliação de escopo; caso não seja incluída, preservar medida com motivo específico de não classificação.

Referência de pesquisa: `https://ropensci.github.io/gigs/reference/gigs_zscoring.html` (seção de observações ao nascimento).

### N03 — P0 / CL-07 — Divergência entre idade corrigida e outra política publicada

A documentação de funções `gigs_waz`/`gigs_lhaz` descreve transição para OMS **sem correção de idade** após 64 semanas de PMA em seus fluxos padrão para prematuros. O produto OctaClin propõe OMS **com idade corrigida**. Isso **não** comprova que a escolha do OctaClin é clinicamente errada, mas impede tratá-la como consequência automática de INTERGROWTH.

**Ação CL-07:** comparar diretrizes pediátricas/neonatais aplicáveis, origem da recomendação, duração, idade usada nos indicadores e técnica; ratificar expressamente corrigida versus cronológica e até quando. Fixar tabela de verdade dos limites 64s0d/64s1d/64s6d e do encerramento da correção. Fonte: `https://ropensci.github.io/gigs/reference/gigs_zscoring.html`.

### N04 — P1 / G00 — Direitos distintos por camada

Tratar separadamente: (a) licença de código, (b) condições de reprodução/redistribuição de tabelas, (c) eventual base de dados/coletânea, (d) atribuição exigida pelo fornecedor e (e) uso interno para conferência de exemplos sintéticos. **Licença MIT de um pacote não garante licença de redistribuição dos dados INTERGROWTH**, assim como licença GPL do código não torna todas as equações científicas proprietárias. Solicitar análise jurídica para a forma exata de incorporação, sem presumir proibição total ou permissão irrestrita.

### N05 — P1 / T01–T10 — Delimitação de bloqueios sem alterar escopo por silêncio

A arquitetura permite, em princípio, separar o trabalho documental de OMS e do neonatal. Entretanto, a autorização atual do proprietário exige resolver G01/G02/G03 antes de T03–T18. **Não reinterpretar a descoberta de bibliotecas como autorização para começar OMS parcialmente.** Se a pesquisa neonatal não puder ser concluída, propor ao proprietário um desmembramento formal de escopo, com gates e entrega/PR próprios, em vez de eliminar prematuros sem decisão.

### N06 — P1 / G00/G05 — Separar prontidão para código da prontidão para produção

`G00` está agregado como BLOCKED por direitos e por prova operacional da 1068. É útil manter substatus independentes: **G00-fonte/direitos** (bloqueia incorporar dados/algoritmos), **G00-operação/1068** (bloqueia rollout, não leitura de documentos). Não alterar a nomenclatura histórica G00–G05 sem rastrear essa decomposição; um estado global BLOCKED permanece correto.

## 5. Perguntas clínicas essenciais para fechar CL-01–CL-10

| CL | Resposta exigida antes da execução |
| --- | --- |
| CL-01 | Regra exata de idade/seleção OMS 2006→2007, meses fracionários e extensão de IMC aos 19 anos |
| CL-02 | Técnica, correção de 0,7 cm, limite de 9 meses, base cronológica/corrigida e reconferência |
| CL-03 | Cálculo por família, caudas, arredondamento, percentis e precisão tolerada |
| CL-04 | Tabela oficial prioritária, igualdades dos pontos de corte e rótulos completos |
| CL-05 | Critérios de elegibilidade por população e primeira medida ao nascer versus pós-natal |
| CL-06 | Fonte/equações contínuas, validação independente e direitos do método INTERGROWTH |
| CL-07 | PMA, borda de 64 semanas, início/fim da correção e OMS com idade corrigida versus não corrigida |
| CL-08 | Pollock 3/7, Faulkner, Guedes, cintura e RCQ individualmente aos 18–19 anos |
| CL-09 | Flags, edema, estado por indicador, medidas pediátricas extremas e reconferência |
| CL-10 | Papéis profissionais existentes, minimização e retenção clínica sem inventar acesso de representante |

Não é adequado aprovar CL-01–CL-10 genericamente sem respostas individualizadas, evidência de fonte e identificação da versão da ficha ratificada em registro interno protegido.

## 6. Gates e ações recomendadas

| Gate | Estado apurado pela documentação | Próxima ação |
| --- | --- | --- |
| G00 | BLOCKED (integridade local parcialmente PASS) | Encerrar direitos de incorporação e, antes do rollout, confirmar 1068 em ambientes autorizados |
| G01 | BLOCKED; **há novo candidato computacional** | Auditar `gigs` e `growthstandards`, modelo, oráculo e fonte original |
| G02 | BLOCKED | Responder e ratificar CL-01–CL-10 com versão/aceite |
| G03 | BLOCKED | Solicitar autorização de implementação somente após gates clínicos/técnicos |
| G04 | SKIPPED | Testes reais só após implementação autorizada |
| G05 | BLOCKED | CI/PG/R4/ambientes/deploy ainda não comprovados |

**Ordem agora:** (1) documentar N01–N06 e fontes no manifesto/ficha/plano/todo sem escrever runtime; (2) concluir pesquisa direcionada T01-C; (3) obter decisões CL-01–CL-10 com destaque para CL-05/06/07; (4) encerrar G01/G02 documentadamente; (5) solicitar G03; (6) somente então executar T03–T18, mantendo T16-A/B antecipadas e o escopo R4.

## 7. Instrução resumida ao Codex

> Consulte o adendo técnico N01–N06 deste parecer. Verifique os dois repositórios científicos indicados como candidatos ao G01 e a distinção entre observações ao nascer, acompanhamento pós-natal e transição para OMS com/sem idade corrigida. Execute apenas a pesquisa e atualização documental T01/T02, preservando o planejamento rev2, as decisões do proprietário e a rastreabilidade. Não copie código/dados, instale pacote novo, altere runtime, execute migrations, abra PR de implementação ou declare G01/G02/G03 PASS. Retorne com evidências, resultados numéricos sintéticos confrontados com oráculo independente, licença por artefato e perguntas clínicas individualizadas que restarem.

## 8. Referências complementares verificáveis

- OMS, referência 5–19 anos: https://www.who.int/tools/growth-reference-data-for-5to19-years
- OMS, ferramentas e AnthroPlus: https://www.who.int/tools/growth-reference-data-for-5to19-years/application-tools
- INTERGROWTH, ferramentas de prematuros: https://intergrowth21.tghn.org/fetal-preterm-and-newborn-applications/
- rOpenSci gigs: https://docs.ropensci.org/gigs/ ; código https://github.com/ropensci/gigs/blob/main/R/ig_png.R
- ki-tools growthstandards: https://ki-tools.github.io/growthstandards/ ; código https://github.com/ki-tools/growthstandards/blob/master/R/standard_igprepost.R
- GIGS, aplicação de referência por ocasião da medida: https://ropensci.github.io/gigs/reference/gigs_zscoring.html

**Limitação:** as verificações de bibliotecas neste parecer consistiram em inspeção da documentação/código-fonte externo, não em execução R, reprodução integral do estudo original nem testes clínicos em pacientes.
