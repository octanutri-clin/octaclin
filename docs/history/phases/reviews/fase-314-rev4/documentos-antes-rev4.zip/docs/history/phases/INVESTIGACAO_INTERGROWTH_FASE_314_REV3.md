# Investigação INTERGROWTH e propostas clínicas — integração REV3

2026-10-10. Escopo autorizado: documentação/pesquisa. A aprovação documental
com ressalvas foi declarada pelo proprietário; **não é ratificação clínica nem
liberação de implementação**. Revisão sobre HEAD `a8db3308`, branch
`docs/fase-314-planejamento`, base local `f8c5ab66`. Worktree inicialmente limpa.
Os seis documentos consolidados foram relidos; os contratos da revisão rev2
continuam preservados. Nenhum banco/estado produtivo foi reconferido neste ciclo.

## 1. Conclusão de viabilidade

**INTERGROWTH pós-natal tem um caminho computacional contínuo viável como
candidato**, para peso e comprimento por PMA. Não é necessário inventar
interpolação dos PDFs semanais. Duas implementações publicam os mesmos
coeficientes; uma avaliação aritmética isolada concordou com o serviço oficial
Oxford em 24 resultados sintéticos, incluindo dias intermediários.

Isso fecha a investigação de existência de um candidato e demonstra concordância
numérica amostral independente. **Não fecha G01:** faltam procedência primária
completa dos coeficientes/precisão, direitos de incorporação concretos, fechamento
OMS e aceites do método/limites. G02 e G03 permanecem BLOCKED. Não há prontidão
para implementação nem produção. Os PDFs não se tornam um modelo diário.

## 2. Fontes fixas, método e diferenças

Fontes científicas: Villar et al. (2015), DOI
[10.1016/S2214-109X(15)00163-1](https://doi.org/10.1016/S2214-109X(15)00163-1),
PMID 26475015. Resumo bibliográfico recuperado por **título** no Europe PMC;
a busca anterior vazia por DOI não demonstrava ausência. O resumo descreve
regressão polinomial fracionária de segundo grau em estrutura multinível,
considerando medidas repetidas; 201 prematuros, únicos, nascidos de 26 a <37
semanas, sem malformações/RCIU/morbidade pós-natal grave, mães selecionadas de
baixo risco. As curvas pós-natais diferem das curvas de tamanho ao nascer e
convergem às OMS perto de 64 semanas de PMA.

Ambos os arquivos R atribuem as equações ao artigo. `gigs` inclui Ohuma como
contribuidor e cita também o artigo do pacote JOSS 10.21105/joss.07655; isso
reforça rastreabilidade, **não substitui suplemento primário nem licença**.
O texto completo/suplemento não foi obtido neste ambiente (Elsevier/Lancet403);
não se afirma que os coeficientes foram diretamente conferidos no suplemento.
A tentativa de URL de suplemento foi exploratória, não fonte identificada.

| Propriedade | ropensci/gigs | ki-tools/growthstandards |
| --- | --- | --- |
| Commit consultado | `fb58fe6596d4b289d5362c5efe00f882984d3186` | `d06a4898c286a3ab9111a5e3525c3b9d0e9ae8aa` |
| Arquivo | `R/ig_png.R` + `R/gigs_zscoring.R` | `R/standard_igprepost.R` |
| Versão DESCRIPTION | 0.5.2.9000, desenvolvimento | 0.1.7 |
| Licença código declarada | GPL (>=3); LICENSE.md recuperado | MIT + LICENSE; texto MIT em LICENSE.md |
| Entrada no núcleo | PMA em semanas exatas | PMA em dias, dividida por 7 |
| Limite efetivo consultado | [27,64] semanas no roteador | [168,454] dias = 24s0d–64s6d |
| Peso/comprimento | log natural, média/desvio por PMA | Mesmas equações e coeficientes |
| Conversão para z | `(ln(y)−μ)/σ` diretamente | z passa por percentil normal e inversa normal |
| Extremos | Cálculo direto evita essa ida/volta | `pnorm` pode saturar 0/1 e `qnorm` devolver infinito |
| Medida ao nascer | Roteamento distinto Newborn Size, primeira <3 dias | Função pós-natal não recebe idade cronológica para distinguir nascimento |
| OMS após 64 | Idade cronológica explicitamente não corrigida | Arquivo isolado não determina política de transição OMS |

O comentário em growthstandards sobre usar Very Early Preterm em 24–33 semanas
não corresponde a um ramo de troca neste arquivo: mesmas equações são usadas.
Não importar essa extensão/comentário como validação. A discordância de limite
não autoriza OctaClin a ampliar a proposta 27s0d–64s0d. O núcleo interno gigs
não aplica sozinho todos os guards; distinguir núcleo e API/roteador público.
Nenhum pacote R foi executado, instalado ou acrescentado como dependência.

### 2.1 Equações candidatas, exclusivamente para revisão

`w = PMA_dias / 7`; `s=1` masculino, `s=0` feminino. Peso `y` em kg,
comprimento `y` em cm. μ e σ referem-se ao **log natural da medida**, não a kg/cm:

```text
Peso:
μ = 2.591277 − 0.01155√w − 2201.705/w² + 0.0911639s
σ = 0.1470258 + 505.92394/w² − 140.0576 ln(w)/w²
Comprimento:
μ = 4.136244 − 547.0018/w² + 0.0026066w + 0.0314961s
σ = 0.050489 + 310.44761/w² − 90.0742 ln(w)/w²
z = (ln(y)−μ)/σ; y(z) = exp(μ+σz); percentil = 100Φ(z)
```

São equações candidatas transcritas para confrontação documental, **não código
incorporado ao runtime nem coeficientes certificados por leitura primária**.
Não aplicar LMS/caudas OMS a essas equações. Não incluir perímetro cefálico,
peso/comprimento neonatal ou Newborn Size no escopo aprovado só por existirem
nos pacotes. A equação WFL de gigs é atribuída a comunicação direta de Ohuma,
fora da referência citada; não adotada nesta fase.

## 3. Concordância independente, apenas dados sintéticos

Oráculo: [calculadora oficial Oxford](https://intergrowth21.ndog.ox.ac.uk/preterm),
ligada pela [página oficial de aplicações](https://intergrowth21.tghn.org/fetal-preterm-and-newborn-applications/).
GET do formulário e POST a `/preterm/en/ManualEntry/Compute`, sem identificador,
data de nascimento, paciente ou credencial. Nenhum instalador/script remoto
executado. A resposta calcula no servidor e inclui arrays `scores`/`centiles`;
foram lidos como números, sem executar JavaScript nem gráficos externos.

Pesquisa local em Python stdlib, isolada em `/tmp/f314-rev3/research.py`:
PMA 27s0d, 27s1d, 36s3d, 40s0d, 63s6d e 64s0d, ambos os sexos;
medidas sintéticas construídas nas proximidades de z −3, −2, 0, +1, +2, +3,
arredondadas a 0,001 kg/0,1 cm antes de consultar o oráculo. São 12 casos,
24 pares de z/percentil. O fato de a entrada ser gerada pela equação não torna
o oráculo independente tautológico: a resposta é calculada pelo serviço oficial;
a prova de ida/volta local, sozinha, não seria suficiente.

- PASS amostral: maior erro absoluto z `1.2101430968414206e-14`;
  percentil `3.126388037344441e-13` pontos percentuais. Comparação descritiva,
  não tolerância clínica definitiva; adotar futura tolerância só após CL-03/06.
- Caso inicial sintético masculino PMA36s3d, 2,65 kg/47,2 cm:
  z peso `0.14070816748856857`, percentil `55.594975371382006`;
  z comprimento `0.09645172112773262`, percentil `53.841909197906723`.
- Quatro PDFs oficiais rebaixados: hashes iguais ao manifesto. Comparados
  38×7×2×2 = **1.064 quantis semanais**, sem pacientes. Erro máximo comprimento
  masculino `0.0498402 cm`, feminino `0.0499110 cm`; peso feminino `0.00496637 kg`.
- **Ressalva real:** peso masculino,55 semanas,z−3: PDF4,40 kg, equação
  `4.405026478034957 kg`; erro `0.005026478034957 kg`, ligeiramente superior
  à meia unidade de arredondamento 0,005 kg. Não ajustar coeficiente/tolerância
  depois de observar o desvio para declarar PASS. Conferir precisão original
  e fechar a discrepância antes de G01. Consulta adicional oficial de4,40 kg
  em55s0d masculino devolveu z `−3.0088689219142397`, igual à equação
  (`−3.00886892191424`). Portanto, oráculo favorece a equação neste ponto,
  mas não explica por que a tabela arredondou4,40 em vez de4,41 kg.
  [Evidência adicional](reviews/fase-314-rev3/quantil55-oraculo-sintetico.json).

Total de consultas sintéticas: 14 casos/28 resultados (lote12/24, caso inicial
36s3d/2 e ressalva55s/2), sem nomes ou identificadores.
[Consulta inicial preservada](reviews/fase-314-rev3/consulta-inicial-sintetica.json).

Arquivos preservados em [evidências REV3](reviews/fase-314-rev3/fontes-pesquisa.json)
e [resultados sintéticos](reviews/fase-314-rev3/comparacao-sintetica.json):
URLs, commits, SHA-256, limites de acesso, entradas e saídas numéricas.
Hashes HTML certificam apenas bytes daquela resposta; serviço oficial não
expõe versão do motor e pode mudar. Não afirmar validação integral diária,
caudas extremas, população, algoritmo OctaClin ou todos os dias por amostragem.
Próxima prova: fonte/edição confirmada, todos os dias e casos extremos contra
oráculo/grade oficial verificável, com tolerância definida antes do confronto.
Percentis nas caudas devem ter apresentação sem falso 0/100 ou precisão excessiva;
limite OMS±3 não é automaticamente política neonatal (CL-03/06).

## 4. Nascimento, pós-natal e transição

Tamanho ao nascer é comparação transversal por IG; crescimento pós-natal é
acompanhamento longitudinal por PMA. O estudo primário adverte que curvas de
nascimento não devem monitorar crescimento pós-natal. `gigs` considera nascimento
a **primeira medida** com idade cronológica <3 dias, e avisa se >0,5 dia.
Isso é política do pacote, não prova de corte clínico universal em72horas;
medidas posteriores dentro da mesma janela podem seguir outro ramo no pacote.

**Preferência proposta CL-05:** excluir day0 e medidas identificadas como
nascimento da classificação pós-natal; 0–2 dias sem classificação automática
até ratificar protocolo específico, conservar medidas e motivo. Não deduzir
“ao nascer” da primeira avaliação cadastrada, que pode ocorrer semanas depois.
Ratificar necessidade de campo explícito do contexto da medida e a janela
inicial; data civil não resolve idade em horas. Nenhuma coleta de hora nova
ou curva Newborn Size está implicitamente autorizada. Alternativa: protocolo
explícito de medidas pós-natais nessa janela com evidência clínica adicional.

O resumo primário recomenda OMS após 64 PMA, mas não resolve no trecho obtido
idade corrigida/cronológica nem prazo. `gigs` escolhe **cronológica**. O produto
OctaClin escolheu **corrigida para revisão**; manter essa proposta até revisão
clínica, identificando divergência. Não copiar roteamento gigs.

**Preferência CL-07:** manter 64s0d inclusive, OMS corrigida em64s1d após
ratificação, PMA=IG+dias, corrigida=cronológica−(280−IG). Exemplo sintético
IG32s0d: em64s1d, cronológica225dias e corrigida169dias, diferença56dias.
Não conectá-las como uma única curva nem zerar idade corrigida negativa.
Alternativa explícita: cronológica conforme GIGS, sujeita a nova decisão e
impacto nos escores; nunca alterar silenciosamente a preferência de produto.

Prazo24/36 meses e base do encerramento continuam sem fonte clínica acessível
que os feche neste ciclo: AAP/HealthyChildren403; SBP 2017 não determina aqui
um prazo completo. **Não há preferência fundamentada para um número específico
sem essa evidência.** Preferir uma política única versionada ratificada pela
equipe com diretriz recuperada, sem seletor livre/alternância ad hoc na UI.
Séries separadas ao fim da correção; aplicar técnica/roteamento à idade
ratificada, conservando ambas. Fora da elegibilidade INTERGROWTH, não concluir
que OMS é automaticamente adequada por a criança ter cruzado64 PMA.

## 5. Direitos e cadeia de fornecimento

| Camada | Evidência | Condição necessária |
| --- | --- | --- |
| Código gigs | DESCRIPTION GPL>=3 + texto GPL | Leitura não impõe adição ao runtime; evitar tradução/cópia do código sem avaliar obrigações |
| Código growthstandards | DESCRIPTION MIT+LICENSE + texto MIT | Preservação de avisos se houver uso autorizado; MIT não concede direitos de dados IG |
| Equações/fatos científicos | Atribuição Villar 2015 nas implementações, oráculo concordante | Obter artigo/suplemento ou confirmação documentada do fornecedor, precisão/origem; avaliar forma de incorporação |
| PDFs/dados/coleções IG | Disponibilidade pública, © Oxford no serviço | Disponibilidade não demonstra licença comercial/redistribuição; esclarecer permissões/atribuição separadamente |
| Obras MS/OMS e datasets | Condições específicas já registradas rev2 | Parecer de direitos para dados/textos efetivamente incorporados, não assumir licença do código vale para tudo |
| Pesquisa interna | Consulta sintética sem dados reais | Não redistribuir instaladores/datasets por inferência; nenhuma dependência executada |

GPL não torna automaticamente equações científicas indisponíveis; MIT não
transforma dados de terceiros em MIT. Preferência: implementação própria
futura a partir da fonte científica autorizada, com atribuição e provas,
sem dependência R/serviço online. Nenhuma decisão jurídica conclusiva feita.

## 6. Integração das ressalvas N01–N06

| REV3 | Conclusão/evidência | Integração |
| --- | --- | --- |
| N01 | Equações contínuas encontradas; oráculo diário sintético concordante (26 resultados), fonte primária detalhada ainda aberta | Manifesto/ficha/T01-C/T09; G01 avança parcialmente, continua BLOCKED |
| N02 | gigs usa primeira medida <3 dias; nascimento difere do pós-natal | CL-05 exige política explícita day0/0–2 dias, sem adicionar Newborn Size |
| N03 | Fonte/código gigs WHO sem correção depois64 | CL-07 preserva proposta corrigida e exige ratificação da divergência/prazo |
| N04 | MIT/GPL verificados em textos distintos; direitos dataset não estabelecidos | G00-fonte/direitos decomposto; nenhum pacote incorporado |
| N05 | Descoberta de biblioteca não autoriza fase parcial OMS | T03–T18 bloqueadas; decomposição de escopo somente por decisão expressa futura |
| N06 | CI/merge não prova migration1068 | G00-operação1068 separado, bloqueio de rollout; sem DB consultado |

Propostas CL completas, com fontes/alternativas/impactos/riscos/ratificação, na
[ficha seção10](../../product/FICHA_VALIDACAO_CLINICA_FASE_314.md#10-propostas-para-ratificação--integração-rev3).
Todos os dez itens exigem decisão humana; nenhuma resposta clínica inferida.

## 7. Gates, cronograma e verificações

G00 global BLOCKED; G00-fonte/direitos BLOCKED (integridade parcialPASS),
G00-operação1068 BLOCKED (consultaSKIPPED). G01/G02/G03 BLOCKED;
G04 SKIPPED; G05 BLOCKED. T01-C pesquisa avançou; T02 ratificação pendente;
T03–T18 não iniciadas. Ordem/IDs/contratos rev2 preservados, refinamentos nos
aceites T01/T02/T09/T10, sem runtime/migrations. Revisão R4 de implementação
continua futura; esta investigação não é revisão independente de código produzido.

Executados: leitura integral REV3/seisdocs; gitstatus/branch/log/diff;
GitHub API/read-only/raw de commits/arquivos/árvores/licenças;
Python urllib/hashlib/HTMLParser e aritmética sintética isolada;
POST de cálculo oficial exclusivamente sintético, quatro PDFs oficiais;
checks documentais e scanner de secrets registrados no handoff.
Tentativas bloqueadas: AAP/HealthyChildren/Elsevier/Lancet403, LICENSE gigs
sem extensão404 corrigido com LICENSE.md; GitHub tags growthstandards401
(não declarar tags/release conferidos). Latest release gigs observadov0.5.2;
commit consultado é desenvolvimento, não release clínico selecionado.
Nenhum R/JS/instalador externo executado; nenhum teste/build do software,
DB/DDL/migration/staging/produção/merge/deploy; todos SKIPPED por escopo.

Parecer original preservado byte a byte em
[ZIP](reviews/fase-314-rev3/parecer-original.zip). Seu hash e o do ZIP estão
no manifesto. Relatórios rev2 continuam históricos; este relatório apresenta
o avanço REV3 sem reescrever a evidência anterior como se sempre existisse.

**Prioridade:** (1) recuperar fonte primária/direitos e ponto55semanas;
(2) equipe ratificar CL-05/06/07 e demais CL com versão/hash;
(3) completar fechamento OMS/G01; (4) registrar G02, solicitar autorização
G03 e escopo de testes; (5) implementar sequência só após esses gates, com Sol 6.1 médio.
Luna alto apenas UI com contratos fechados e troca manual avisada/pausada.
1068/roles/RLS/grants exigem evidência operacional autorizada antes de rollout.

## Verificações da consolidação REV3

PASS: `git diff --check`; Python stdlib conferiu links locais/âncoras e
colunas Markdown, CL-01–CL-10/IDs T01–T18 e ZIP byte a byte. PASS:
`pnpm security:secrets`, sem segredo real; aviso Node24/pnpm11 fora da faixa
do projeto registrado, sem afirmar compatibilidade do software.
PASS documental: integridade das fontes, amostras sintéticas contra oráculo;
ressalva semanal55s permanece explícita. Nenhuma dessas provas é teste do
runtime OctaClin. SKIPPED: Jest/PG/authz/Playwright/builds/CI314 e qualquer
banco/migration/staging/produção/merge/deploy. Diff limitado à documentação314.
