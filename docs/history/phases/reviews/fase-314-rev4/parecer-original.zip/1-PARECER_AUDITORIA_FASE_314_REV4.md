# Parecer de auditoria documental — Fase 314, revisão REV4

**Data:** 10/10/2026  
**Objeto:** `todo-fase-314 3.md`, `PLANO_FASE_314 2.md`, `INVESTIGACAO_INTERGROWTH_FASE_314_REV3.md`, `FICHA_VALIDACAO_CLINICA_FASE_314 3.md`.  
**Natureza:** auditoria técnica-documental externa e pesquisa científica complementar. **Não representa ratificação clínica, parecer jurídico, auditoria de código executável ou autorização de deploy.** Não foram executados testes do OctaClin, migrações ou alterações no repositório nesta revisão.

## 1. Resultado executivo

**Parecer:** **planejamento tecnicamente consistente e apto à etapa de decisões formais, com condicionantes relevantes; implementação da Fase 314 ainda bloqueada.** A pesquisa REV3 representa avanço real: identifica equações pós-natais contínuas para INTERGROWTH (peso e comprimento por idade pós-menstrual), compara duas implementações públicas e registra resultados amostrais concordantes com a calculadora oficial de Oxford. A ausência de modelo diário deixou de ser uma lacuna sem candidato; não foi convertida em comprovação integral de método, população, precisão, licença ou prontidão.

**Estados documentados:** G00-fonte/direitos **BLOCKED**; G00-operação/1068 **BLOCKED**, consulta externa SKIPPED; G01 **BLOCKED**; G02 **BLOCKED**; G03 **BLOCKED**; G04 **SKIPPED**; G05 **BLOCKED**. A autorização continua restrita a pesquisa e documentação. T03–T18 não iniciadas.

**Avaliação por arquivo:**

| Documento | Avaliação | Ressalva |
| --- | --- | --- |
| `INVESTIGACAO_INTERGROWTH_FASE_314_REV3.md` | Pesquisa reproduzível em sua descrição, com limites e origens distinguidos | Reproduzir oráculo a partir das evidências locais quando estiverem disponíveis; procedência primária/licenças permanecem abertas |
| `FICHA_VALIDACAO_CLINICA_FASE_314 3.md` | CL-01–CL-10 bem organizadas, opções e riscos distinguem fato de decisão | Nova literatura sobre correção da idade deve enriquecer CL-07; decisão específica por IG e duração permanece humana |
| `PLANO_FASE_314 2.md` | Contrato de snapshot cifrado, RLS, idempotência, papéis, paginação e rollback adequadamente previsto | G00-fonte e G00-operação não devem ser tratados como o mesmo tipo de impedimento; cabe rever a possibilidade de provar ambos separadamente |
| `todo-fase-314 3.md` | Ordem e checkpoints corrigidos; T11 antes de T06, T16-A/B antes da UI | Tornar conjunto de provas do oráculo limitado, repetível, suficiente e não dependente do serviço externo em CI |

## 2. Achados prioritários REV4

### A01 — P0 clínico: nova evidência para CL-07 (prazo da idade corrigida)

O texto REV3 afirma que ainda faltava fonte acessível que fundamentasse a comparação entre 24 e 36 meses. Foi localizada literatura científica diretamente acessível:

1. Elmrayed S et al. *Preterm growth assessment: the latest findings on age correction*, Journal of Perinatology, publicado em 16/01/2025. Estudo longitudinal de 1.416 crianças nascidas com IG <32 semanas; conclui que a idade corrigida impacta significativamente a classificação antropométrica até **36 meses de idade corrigida** na população extremamente e muito prematura. https://www.nature.com/articles/s41372-024-02202-z
2. Sociedade Brasileira de Pediatria (2023), *A criança prematura: suas peculiaridades e o papel da família*. Orienta considerar idade corrigida durante os **primeiros dois anos de vida** no contexto de acompanhamento do desenvolvimento. É suporte clínico importante, mas **não é, isoladamente, um protocolo computacional de limites antropométricos** para todas as populações. https://www.sbp.com.br/pediatria-para-familias/primeira-infancia/a-crianca-prematura-suas-peculiaridades-e-o-papel-da-familia/
3. Royal College of Paediatrics and Child Health, UK-WHO neonatal and infant close monitoring charts: curva acompanha prematuros até **2 anos de idade corrigida** no desenho específico daquele instrumento. https://www.rcpch.ac.uk/resources/uk-who-growth-charts-neonatal-infant-close-monitoring-nicm
4. Fonte de referência sobre a mudança INTERGROWTH → OMS: Villar et al., Lancet Global Health (2015), PubMed PMID 26475015. A referência pós-natal vai até 64 semanas de PMA, mas o resumo não estabelece a duração específica da correção posteriormente. https://pubmed.ncbi.nlm.nih.gov/26475015/

**Consequência:** a discussão 24 versus 36 meses não deve ficar descrita como carente de qualquer fonte. Ao mesmo tempo, o achado de 2025 não justifica automaticamente impor 36 meses a todos os prematuros: a amostra se restringe à IG <32 semanas. A equipe clínica deverá escolher entre política única e política por faixas de IG, esclarecer se a janela é medida em idade cronológica/corrigida, e ratificar casos nascidos com ≥32 semanas. Não alterar CL-07 sem registrar fonte, população, alternativa e tabela de verdade.

### A02 — P0 de produto/clínica: separação nascimento/pós-natal

O material diferencia corretamente curva de tamanho ao nascer da curva de acompanhamento pós-natal. A sugestão conservadora de não classificar automaticamente a janela de 0–2 dias é **proposta local**, não regra oficial universal. Precisa de aceite, mensagem clara por indicador, fonte do contexto da medida e comprovação de que a primeira avaliação no OctaClin não está sendo tratada como medição ao nascer. Não implementar um padrão Newborn Size adicional por inferência.

### A03 — P0 computacional: validação INTERGROWTH ainda condicionada

A investigação descreve o modelo candidato `z=(ln(y)-μ)/σ` para peso/comprimento e equivalência amostral com oráculo de Oxford. É evidência forte de **concordância numérica pontual**, não confirmação completa dos coeficientes junto ao autor nem validação de todos os dias, medidas extremas, população e direitos. A discrepância semanal de 55 semanas/z−3 (equação 4,405026... kg versus tabela 4,40 kg) deve continuar visível; oráculo concordante com z do modelo sugere diferença de apresentação/precisão, mas ainda requer esclarecimento documental. Antes de declarar G01 PASS: identificar edição científica/precisão, política de extremos/percentis, tolerâncias fixadas a priori, casos independentes e autorização da incorporação.

### A04 — P1 de metodologia: suíte externa finita e fixa

Evitar converter 'todos os dias contra o site externo' em dependência frágil de centenas de consultas sem limite. Recomenda-se:
- Vetores sintéticos determinísticos cobrindo 27s0d, dias intermediários, transição 64s0d/64s1d, ambos os sexos, z próximos de −3/−2/0/+2/+3 e extremos positivos válidos;
- Testes locais exaustivos de propriedades/domínio/monotonicidade/medidas negativas e finitas, quando pertinentes;
- Casos selecionados e distribuídos comparados com oráculo independente de versão ou registro de resposta/hash, sob condições de uso adequadas, com limiar de erro pré-definido;
- CI funcionando inteiramente offline sem tráfego de dados de pacientes, sem disponibilizar respostas de usuários reais a terceiros.

Não aumentar a tolerância só para aprovar o caso discrepante de 55 semanas.

### A05 — P0 direitos: distinguir obra, programa, equações e dados

O artigo de Villar et al. é apresentado na página do periódico com licença **CC BY-NC-ND**; isso não é licença automática para copiar obra ou quadros para SaaS comercial. A GPL declarada por `gigs` e a MIT declarada por `growthstandards` regem implementações de código e não transferem automaticamente todos os direitos sobre os datasets ou a obra científica. Avaliar forma concreta de incorporação, permissões necessárias, atribuição e eventual consulta ao fornecedor do INTERGROWTH antes de incorporar. Disponibilidade pública e concordância matemática não bastam para fechar G00-fonte/direitos.

**Contato documental sugerido:** página oficial de recursos INTERGROWTH: https://intergrowth21.tghn.org/standards-tools/ (indica contato para dúvidas sobre recursos). Não enviar dados reais de pacientes.

### A06 — P1 segurança e operação: preservar gates separados

O documento separou acertadamente G00-fonte/direitos de G00-operação1068. Confirmar application/roles/grants/RLS da migration em staging/produção é requisito de implantação e não precisa impedir pesquisa documental. O caso de snapshots ilegíveis, cursor com ancoragem em registro excluído, paginação por registros examinados e revalidação da carteira a cada página devem permanecer como provas em PostgreSQL real. Não presumir que trigger UPDATE de 1068 impede DELETE físico.

### A07 — P1 UX/consistência: resultados parcialmente indisponíveis

Um indicador não classificável não deve zerar valores nem ocultar os demais. A equipe precisa ratificar estados/motivos por indicador e apresentação de flags, idade cronológica/corrigida/PMA, transição entre curvas, dados de nascimento e alertas de reconferência. Não transportar ajuste ±0,7 cm OMS para INTERGROWTH sem aprovação, e não desenhar linhas contínuas entre bases de idade/referências distintas.

### A08 — P2 documental: conciliar contagens de consultas ao oráculo

Há uma inconsistência editorial verificável entre os documentos atualizados: a investigação detalhada (seção 3) registra **12 casos/24 resultados** no lote principal, mais **um caso inicial/2 resultados** e **um caso 55 semanas/2 resultados**, totalizando **14 casos/28 resultados**. Já o plano (seção 11) e a ficha CL-03 mencionam **26 resultados**. Recomendo que o Codex reconcilie as contagens diretamente com os JSONs de evidências e declare separadamente o lote principal, o exemplo inicial e a verificação adicional, sem alterar os dados ou os limites metodológicos. Essa inconsistência não invalida, sozinha, o candidato matemático, mas precisa ser corrigida para que os relatórios sejam auditáveis.

## 3. Decisões clínicas pendentes CL-01–CL-10

| Código | Decisão que precisa de resposta formal |
| --- | --- |
| CL-01 | Edição OMS, idade civil vs estatística, transição 60 meses e bordas 120/228/229 e 19→20 anos |
| CL-02 | Técnica/posição, ajuste 0,7 cm e manejo de em pé <9 meses, inclusive idade aplicável |
| CL-03 | LMS/caudas/percentis OMS; z bruto vs duas casas; tolerâncias e apresentação INTERGROWTH |
| CL-04 | Edição prioritária SISVAN, nomes completos, limites inclusivos/exclusivos por indicador |
| CL-05 | Elegibilidade neonatal, nascimento vs acompanhamento, IG e comorbidades, dias 0–2 |
| CL-06 | Modelo diário INTERGROWTH, domínio, procedimento de validação, coeficientes, direitos e ressalva 55s |
| CL-07 | Transição após PMA 64s0d, idade corrigida vs cronológica, duração 24/36/outro e pertinência por IG; **incorporar estudo de 2025** |
| CL-08 | Pollock 3, Pollock 7, Faulkner, Guedes, cintura e RCQ aos 18–19, cada qual com fonte/população |
| CL-09 | Edema, flags, limites físicos, precisão e o que exibir quando o indicador é flagado |
| CL-10 | Papéis, finalidade, acesso a dados de menores, minimização, RLS, histórico, retenção e retificação |

**Ratificação sugerida:** equipe com experiência pediátrica/neonatal, registrando versão/hash, fundamentação e exceções por CL, de maneira interna e protegida. A aprovação do documento pelo proprietário não substitui a ratificação dos critérios especializados.

## 4. Próximo trabalho documental recomendado

1. Acrescentar A01 (fontes 2025/SBP/RCPCH) ao manifesto e CL-07; distinguir recomendações de desenvolvimento e evidência específica para crescimento. Registrar proposta preferencial com alternativas e população por IG, sem fechar unilateralmente a questão.
2. Verificar a cadeia de direitos das equações e dados, inclusive consulta ao INTERGROWTH quando necessário; tratar o texto científico sob sua licença real.
3. Conferir origem e precisão dos coeficientes, explicar sem forçar ajuste a diferença de 55 semanas e fixar critérios de tolerância/prova independente.
4. Propor respostas finais da equipe para CL-01–CL-10 em formato decisório compacto, com campo para aprovação/alteração e evidência. Não escrever aceites como se já existissem.
5. Depois dos requisitos documentais e da ratificação G01/G02, solicitar autorização específica G03. Em implementação, manter a ordem T03 → T04 → T05 → T11 → T06 → T16-A → T07 → T08 → T09 → T10 → T12 → T16-B → T13 → T14 → T15 → T16-C → T17 → T18.
6. Verificar migration1068/role/RLS/grants e saúde de produção somente em etapa operacional autorizada; nenhuma pesquisa atual os comprova.

## 5. Parecer de liberação

- **Planejamento documental:** APROVÁVEL COM RESSALVAS, com incorporação das novas fontes em CL-07 e ajustes de metodologia e direitos.
- **Viabilidade matemática INTERGROWTH:** FAVORÁVEL como candidato pesquisado, sem ratificação integral.
- **G00/G01/G02:** BLOCKED (dependências específicas ainda abertas).
- **G03:** autorização de implementação não recebida nesta etapa.
- **G04:** SKIPPED (sem código nem testes executados).
- **G05:** BLOCKED (sem comprovação operacional nem autorização de implantação).

**Escopo desta auditoria:** leitura dos quatro documentos enviados e verificação externa das referências científicas indicadas. Os cálculos/consultas ao oráculo relatados na REV3 não foram repetidos nesta sessão; seus resultados são tratados como *evidência documental fornecida pelo Codex*, não como testes independentes executados pelo revisor. Nenhuma alteração foi feita nos arquivos originais ou no repositório do OctaClin.
